IF  EXISTS (select * from syscolumns where id=object_id('esap_tx') and name='id')
ALTER TABLE esap_tx DROP COLUMN ID  

ALTER TABLE esap_tx ADD id INT IDENTITY(1,1)

IF  EXISTS (select * from syscolumns where id=object_id('esap_cx') and name='id')
ALTER TABLE esap_cx DROP COLUMN ID  

ALTER TABLE esap_cx ADD id INT IDENTITY(1,1)

IF  EXISTS (select * from syscolumns where id=object_id('esap_sms') and name='id')
ALTER TABLE esap_sms DROP COLUMN ID  

ALTER TABLE esap_sms ADD id INT IDENTITY(1,1)

IF  EXISTS (select * from syscolumns where id=object_id('esap_k') and name='id')
ALTER TABLE esap_k DROP COLUMN ID  

ALTER TABLE esap_k ADD id INT IDENTITY(1,1)

IF  EXISTS (select * from syscolumns where id=object_id('esap_dw') and name='id')
ALTER TABLE esap_dw DROP COLUMN ID  

ALTER TABLE esap_dw ADD id INT IDENTITY(1,1)

IF  EXISTS (select * from syscolumns where id=object_id('esap_mail') and name='id')
ALTER TABLE esap_mail DROP COLUMN ID  

ALTER TABLE esap_mail ADD id INT IDENTITY(1,1)

IF  EXISTS (select * from syscolumns where id=object_id('esap_idcard') and name='id')
ALTER TABLE esap_idcard DROP COLUMN ID  

ALTER TABLE esap_idcard ADD id INT IDENTITY(1,1)

alter table esap_cx 
alter column safe int
alter table esap_cx 
alter column mode int