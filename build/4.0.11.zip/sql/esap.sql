/****** 系统设置，邮箱等    Script Date: 04/10/2018 11:36:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_sys]') AND type in (N'U'))
DROP TABLE [dbo].[esap_sys]

CREATE TABLE [dbo].[esap_sys](
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL,
	[UseSmtp] [decimal](32, 0) NULL,
	[SmtpServer] [nvarchar](128) NULL,
	[SmtpPort] [decimal](32, 0) NULL,
	[SmtpAuth] [decimal](32, 0) NULL,
	[SmtpUseSSL] [decimal](32, 0) NULL,
	[EmailSender] [nvarchar](128) NULL,
	[EmailAddress] [nvarchar](128) NULL,
	[EmailPassword] [nvarchar](128) NULL
)

/****** 身份证    Script Date: 04/10/2018 11:35:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_idcard]') AND type in (N'U'))
DROP TABLE [dbo].[esap_idcard]

CREATE TABLE [dbo].[esap_idcard](
	[身份证] [nvarchar](100) NULL,
	[姓名] [nvarchar](100) NULL,
	[性别] [nvarchar](1) NULL,
	[民族] [nvarchar](100) NULL,
	[生日] [datetime] NULL,
	[住址] [nvarchar](100) NULL,
	[签发机关] [nvarchar](100) NULL,
	[签发日] [datetime] NULL,
	[失效日] [datetime] NULL,
	[创建人] [nvarchar](100) NULL,
	[创建日] [datetime] NULL,
	[pic] [nvarchar](100) NULL,
	[pic2] [nvarchar](100) NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[描述] [nvarchar](50) NULL,
	[app] [nvarchar](20) NULL,
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL
) 

/****** 百度AI    Script Date: 04/10/2018 11:34:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_ai]') AND type in (N'U'))
DROP TABLE [dbo].[esap_ai]

CREATE TABLE [dbo].[esap_ai](
	[号码] [nvarchar](100) NULL,
	[证号] [nvarchar](100) NULL,
	[创建人] [nvarchar](100) NULL,
	[创建日] [datetime] NULL,
	[pic] [nvarchar](100) NULL,
	[描述] [nvarchar](50) NULL,
	[app] [nvarchar](100) NULL,
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL,
	[有效期] [nvarchar](20) NULL,
	[地址] [nvarchar](500) NULL,
	[法人] [nvarchar](100) NULL,
	[电话] [nvarchar](100) NULL,
	[传真] [nvarchar](100) NULL,
	[QQ] [nvarchar](100) NULL,
	[名称] [nvarchar](500) NULL,
	[类型] [nvarchar](20) NULL
) 

/****** 打卡记录    Script Date: 09/16/2017 08:42:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_dk]') AND type in (N'U'))
DROP TABLE [dbo].[esap_dk]

CREATE TABLE [dbo].[esap_dk](
	[用户] [nvarchar](100) NOT NULL,
	[组名] [nvarchar](100) NULL,
	[类型] [nvarchar](100) NULL,
	[异常] [nvarchar](100) NULL,
	[时间] [datetime] NOT NULL,
	[地点] [nvarchar](500) NULL,
	[地点详情] [nvarchar](500) NULL,
	[wifi] [nvarchar](100) NULL,
	[备注] [nvarchar](500) NULL,
	[wifiMAC] [nvarchar](100) NULL,
	[userid] [nvarchar](100) NULL,
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL,
	[app] [nvarchar](20) NULL
)

/****** 邮件    Script Date: 09/16/2017 08:42:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_mail]') AND type in (N'U'))
DROP TABLE [dbo].[esap_mail]

CREATE TABLE [dbo].[esap_mail](
	[cDate] [datetime] NULL,
	[mailTo] [nvarchar](500) NULL,
	[Subject] [nvarchar](100) NULL,
	[Content] [nvarchar](500) NULL,
	[Pic] [nvarchar](1000) NULL,
	[Files] [nvarchar](1000) NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[flag] [int] NULL,
	[mailFrom] [nvarchar](100) NULL,
	[pwd] [nvarchar](100) NULL,
	[ret] [nvarchar](100) NULL,
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL
)

/****** 签到    Script Date: 09/16/2017 08:42:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_dw]') AND type in (N'U'))
DROP TABLE [dbo].[esap_dw]

CREATE TABLE [dbo].[esap_dw](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[cDate] [datetime] NULL,
	[usr] [nvarchar](100) NULL,
	[name] [nvarchar](100) NULL,
	[lx] [decimal](10, 6) NULL,
	[ly] [decimal](10, 6) NULL,
	[url] [nvarchar](1000) NULL,
	[addr] [nvarchar](100) NULL,
	[rec] [nvarchar](100) NULL,
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL,
	[app] [nvarchar](20) NULL
)

/****** 多媒体库    Script Date: 04/10/2018 11:31:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_k]') AND type in (N'U'))
DROP TABLE [dbo].[esap_k]

CREATE TABLE [dbo].[esap_k](
	[pic] [nvarchar](200) NULL,
	[mDesc] [nvarchar](100) NULL,
	[cDate] [datetime] NULL,
	[name] [nvarchar](100) NULL,
	[usr] [nvarchar](100) NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[app] [nvarchar](20) NULL,
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL,
	[fh] [nvarchar](20) NULL,
	[mType] [nvarchar](20) NULL
)

/****** 短信    Script Date: 12/13/2017 10:50:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_sms]') AND type in (N'U'))
DROP TABLE [dbo].[esap_sms]

CREATE TABLE [dbo].[esap_sms](
	[tel] [nvarchar](100) NULL,
	[content] [nvarchar](500) NULL,
	[result] [nvarchar](500) NULL,
	[sid] [nvarchar](500) NULL,
	[fee] [int] NULL,
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](100) NULL
)

/****** 查询    Script Date: 03/19/2018 14:28:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_cx]') AND type in (N'U'))
DROP TABLE [dbo].[esap_cx]

CREATE TABLE [dbo].[esap_cx](
	[mKey] [nvarchar](100) NULL,
	[name] [nvarchar](100) NULL,
	[entermsg] [nvarchar](1000) NULL,
	[tmpl] [ntext] NULL,
	[aclUser] [nvarchar](500) NULL,
	[aclDept] [nvarchar](500) NULL,
	[aclTag] [nvarchar](500) NULL,
	[mode] [int] NULL,
	[app] [nvarchar](100) NULL,
	[db] [nvarchar](100) NULL,
	[safe] [int] NULL,
	[url] [nvarchar](1000) NULL,
	[pic] [nvarchar](1000) NULL,
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[aclApp] [nvarchar](500) NULL,
	[nextFn] [nvarchar](100) NULL,
	[erp8] [nvarchar](100) NULL,
	[tmpId] [nvarchar](100) NULL,
	[appId] [nvarchar](100) NULL
)

/****** 提醒    Script Date: 09/16/2017 08:43:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[esap_tx]') AND type in (N'U'))
DROP TABLE [dbo].[esap_tx]

CREATE TABLE [dbo].[esap_tx](
	[flag] [int] NULL,
	[cDate] [datetime] NULL,
	[app] [nvarchar](20) NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[toUser] [nvarchar](500) NULL,
	[toParty] [nvarchar](500) NULL,
	[toTag] [nvarchar](500) NULL,
	[content] [nvarchar](1000) NULL,
	[fh] [nvarchar](1000) NULL,
	[pic] [nvarchar](1000) NULL,
	[title] [nvarchar](100) NULL,
	[url] [nvarchar](1000) NULL,
	[safe] [int] NULL,
	[ret] [nvarchar](500) NULL,
	[db] [nvarchar](100) NULL,
	[RecordID] [int] NULL,
	[CreateTime] [datetime] NULL,
	[tmpId] [nvarchar](100) NULL,
	[tmpParams] [nvarchar](100) NULL
)